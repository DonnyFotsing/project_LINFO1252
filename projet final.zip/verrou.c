#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

typedef struct {
    int lock;
} slock_t;

void lock(slock_t *s) {
    int expected;
    do {
        expected = 0;
        asm volatile (
            "xchg %0, %1"
            : "=r"(expected), "=m"(s->lock)
            : "0"(1), "m"(s->lock)
            : "memory"
        );
    } while (expected != 0);
}

void unlock(slock_t *s) {
    asm volatile (
        "movl $0, %0"
        : "=m"(s->lock)
        :
        : "memory"
    );
}

slock_t lock_instance = {0};
int number;

void *worker(void *arg) {
    for (int i = 0; i < number; i++) {
        lock(&lock_instance);
        for (int j = 0; j < 10000; j++); 
        unlock(&lock_instance);
    }
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        return 1;
    }
    int num_threads = atoi(argv[1]);
    number = 32768 / num_threads;
    pthread_t threads[num_threads];
    for (int i = 0; i < num_threads; i++) {
        pthread_create(&threads[i], NULL, worker, NULL);
    }
    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }
    return 0;
}
