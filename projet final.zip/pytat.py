import pandas as pd
import matplotlib.pyplot as plt

def time_to_seconds(time_str):
    try:
        minutes, seconds = time_str.strip("s").split("m")
        return int(minutes) * 60 + float(seconds)
    except ValueError:
        return None
data = pd.read_csv("performance_comparison.csv")
for col in data.columns[1:]:  
    data[col] = data[col].apply(time_to_seconds)


data["TAS_Mean"] = data.iloc[:, 1:6].mean(axis=1)
data["TAS_StdDev"] = data.iloc[:, 1:6].std(axis=1)
data["TTAS_Mean"] = data.iloc[:, 6:11].mean(axis=1)
data["TTAS_StdDev"] = data.iloc[:, 6:11].std(axis=1)

# Extraire les données nécessaires pour le graphique
thread_counts = data["Nb_threads"]
tas_means = data["TAS_Mean"]
tas_stddevs = data["TAS_StdDev"]
ttas_means = data["TTAS_Mean"]
ttas_stddevs = data["TTAS_StdDev"]

# Tracer les graphes
plt.figure(figsize=(12, 6))
plt.errorbar(thread_counts, tas_means, yerr=tas_stddevs, fmt='-o', label="Test-and-Set", capsize=5)
plt.errorbar(thread_counts, ttas_means, yerr=ttas_stddevs, fmt='-s', label="Test-and-Test-and-Set", capsize=5)

plt.title("Comparaison de la performance : Test-and-Set vs Test-and-Test-and-Set", fontsize=14)
plt.xlabel("Nombre de threads", fontsize=12)
plt.ylabel("Temps d'exécution (secondes)", fontsize=12)
plt.xscale('log', base=2)
plt.grid(True, linestyle="--", alpha=0.6)
plt.legend(fontsize=12)


plt.savefig("tas_vs_ttas_performance.png", dpi=300)
plt.show()
