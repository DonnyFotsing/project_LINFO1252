#!/bin/bash

THREADS=("2" "4" "8" "16" "32")
MIN_BACKOFF_VALUES=("100" "500" "1000" "5000" "10000")
MAX_BACKOFF_VALUES=("500" "1000" "5000" "10000" "20000") 
OUTPUT_FILE="results.csv"
gcc -o backoff_test back.c
echo "num_threads,min_backoff,max_backoff,time_seconds" > $OUTPUT_FILE
for threads in "${THREADS[@]}"; do
    for min_backoff in "${MIN_BACKOFF_VALUES[@]}"; do
        for max_backoff in "${MAX_BACKOFF_VALUES[@]}"; do
            for i in {1..5}; do
                result=$( { time ./backoff_test $threads $min_backoff $max_backoff > /dev/null; } 2>&1 | grep real | awk '{print $2}')
                echo "$threads,$min_backoff,$max_backoff,$result" >> $OUTPUT_FILE
            done
        done
    done
done

echo "Tests terminés. Résultats enregistrés dans $OUTPUT_FILE"
