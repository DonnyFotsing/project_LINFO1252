#!/bin/bash
echo "Nb_threads,Measure_1,Measure_2,Measure_3,Measure_4,Measure_5" > philosophe.csv

# Compilation
gcc -o philosopher projet1.c -pthread || { echo "Compilation failed!"; exit 1; }
for i in 2 4 8 16 32; do
    echo -n "$i," >> philosophe.csv
    for _ in 1 2 3 4 5; do
        TIME=$( { time ./philosopher $i > /dev/null; } 2>&1 | grep real | awk '{print $2}')
        echo -n "$TIME;" >> philosophe.csv
    done
    echo "" >> philosophe.csv
done

