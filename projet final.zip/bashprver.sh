#!/bin/bash
echo "Nb_threads,Measure_1,Measure_2,Measure_3,Measure_4,Measure_5" > prcon_ver.csv

gcc -o producers_consumers_ver prconver.c -pthread || { echo "Compilation failed!"; exit 1; }
for total_threads in 2 4 8 16 32; do
    num_producers=$((total_threads / 2))
    num_consumers=$((total_threads / 2))
    echo -n "$total_threads," >> prcon_ver.csv
    for _ in 1 2 3 4 5; do
        TIME=$( { time ./producers_consumers_ver $num_producers $num_consumers > /dev/null; } 2>&1 | grep real | awk '{print $2}')
        echo -n "$TIME;" >> prcon_ver.csv
    done
    echo "" >> prcon_ver.csv
done

# Message de fin
echo "Mesures collectées et enregistrées dans prcon_ver.csv"
