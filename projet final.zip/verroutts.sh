#!/bin/bash

# Compilation des programmes
gcc -o test_and_set verrou.c -lpthread
gcc -o test_and_test_and_set verroutat.c -lpthread

# Fichier de sortie
OUTPUT_FILE="performance_comparison.csv"
echo "Nb_threads,TAS_Measure_1,TAS_Measure_2,TAS_Measure_3,TAS_Measure_4,TAS_Measure_5,TTAS_Measure_1,TTAS_Measure_2,TTAS_Measure_3,TTAS_Measure_4,TTAS_Measure_5" > $OUTPUT_FILE

# Configuration
THREAD_COUNTS=(1 2 4 8 16 32)
REPEATS=5


for threads in "${THREAD_COUNTS[@]}"; do
   
    echo -n "$threads" >> $OUTPUT_FILE

    # Mesures pour Test-and-Set
    for ((i = 0; i < REPEATS; i++)); do
        TIME=$( { time ./test_and_set $threads > /dev/null; } 2>&1 | grep real | awk '{print $2}')
        echo -n ",$TIME" >> $OUTPUT_FILE
    done

    # Mesures pour Test-and-Test-and-Set
    for ((i = 0; i < REPEATS; i++)); do
        TIME=$( { time ./test_and_test_and_set $threads > /dev/null; } 2>&1 | grep real | awk '{print $2}')
        echo -n ",$TIME" >> $OUTPUT_FILE
    done

    # Fin de ligne pour ce nombre de threads
    echo "" >> $OUTPUT_FILE
done

