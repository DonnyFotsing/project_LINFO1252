import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

data = pd.read_csv("performance_test_and_set.csv")

data["Mean"] = data.iloc[:, 1:].mean(axis=1)  # Moyenne des mesures (colonnes 2 à 6)
data["StdDev"] = data.iloc[:, 1:].std(axis=1)  # Écart type des mesures (colonnes 2 à 6)

# Extraire les configurations et les statistiques
thread_counts = data["Nb_threads"]
means = data["Mean"]
std_devs = data["StdDev"]

# Tracer le graphique
plt.figure(figsize=(10, 6))
plt.errorbar(thread_counts, means, yerr=std_devs, fmt='-o', capsize=3, label="Temps moyen ± écart-type")

plt.title("Performance du verrou test-and-set", fontsize=14)
plt.xlabel("Nombre de threads", fontsize=12)
plt.ylabel("Temps d'exécution (secondes)", fontsize=12)
plt.xticks(thread_counts, fontsize=10) 
plt.yticks(fontsize=10)
plt.ylim(0)
plt.grid(True, linestyle="--", alpha=0.6)
plt.legend(fontsize=12)

# Sauvegarder et afficher
plt.savefig("test_and_set_performance.png", dpi=300)
plt.show()
