import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Fonction pour extraire les secondes de la chaîne de temps
def extract_seconds(time_str):
    """Convertit une chaîne de temps en secondes."""
    if 'm' in time_str and 's' in time_str:
        minutes, seconds = time_str.split('m')
        seconds = seconds.replace('s', '') 
        return float(seconds) + int(minutes) * 60
    elif 's' in time_str:
        return float(time_str.replace('s', ''))
    return 0.0

# Charger les données depuis le CSV
df = pd.read_csv('results.csv')

# Dictionnaire pour stocker les mesures par nombre de threads
measures = {2: [], 4: [], 8: [], 16: [], 32: []}

# Extraire les données et les convertir en secondes
for _, row in df.iterrows():
    try:
        nb_threads = int(row['num_threads'])  # Nombre de threads
        time = row['time_seconds']  # Temps en secondes
        if isinstance(time, str) and time.strip() != "Measure file does not exist." and time.strip() != "Erreur lors de la mesure":
            time = extract_seconds(time)
            if nb_threads in measures:
                measures[nb_threads].append(time)
    except ValueError:
        print(f"Skipping row with invalid num_threads or time_seconds value: {row['num_threads']}, {row['time_seconds']}")  

# Calculer la moyenne et l'écart-type pour chaque nombre de threads
mean_times = []
std_times = []

for nb_threads in sorted(measures.keys()):
    times = measures[nb_threads]
    if times: 
        mean_times.append(np.mean(times))
        std_times.append(np.std(times))
    else:
        mean_times.append(np.nan) 
        std_times.append(np.nan)

# Créer un DataFrame avec les résultats
results_df = pd.DataFrame({
    'Nb_threads': list(measures.keys()),
    'Mean_time': mean_times,
    'Std_time': std_times
})

# Afficher les résultats
print(results_df)

# Supprimer les lignes avec des valeurs NaN
valid_results = results_df.dropna()

# Vérifier s'il y a des résultats valides
if valid_results.empty:
    print("Aucun résultat valide pour le graphique.")
else:
    # Préparer les données pour le graphique
    x = valid_results['Nb_threads']  # Nombre de threads
    y = valid_results['Mean_time']   # Temps moyen
    yerr = valid_results['Std_time'] # Ecart-type
    
    # Créer le graphique
    plt.figure(figsize=(8, 6))
    plt.errorbar(x, y, yerr=yerr, fmt='-o', capsize=5, color='blue', label='Temps moyen avec écart-type')
    
    # Ajouter le titre et les labels
    plt.title('Temps d\'exécution en fonction du nombre de threads')
    plt.xlabel('Nombre de threads')
    plt.ylabel('Temps d\'exécution (secondes)')
    
    # Personnaliser les ticks
    plt.xticks(valid_results['Nb_threads'])
    plt.yticks(np.arange(0, max(valid_results['Mean_time'])+0.1 , 0.1))
    
    # Ajouter la grille et la légende
    plt.grid(True)
    plt.legend()
    
    # Ajuster la mise en page
    plt.tight_layout()
    
    # Afficher le graphique
    plt.show()
