


#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>


typedef struct {
    int lock;
} slock_t;


void lock(slock_t *s, int min_backoff, int max_backoff) {
    int expected;
    int backoff = min_backoff;
    
    do {
        expected = 0;
        asm volatile (
            "xchg %0, %1"
            : "=r"(expected), "=m"(s->lock)
            : "0"(1), "m"(s->lock)
            : "memory"
        );

        if (expected != 0) {
            // Backoff si le verrou est pris
            usleep(backoff);  // Attente active avec un délai de backoff
            if (backoff < max_backoff) {
                backoff *= 2;  // Augmenter le backoff jusqu'à la valeur maximale
            }
        }
    } while (expected != 0);
}

void unlock(slock_t *s) {
    asm volatile (
        "movl $0, %0"
        : "=m"(s->lock)
        :
        : "memory"
    );
}

slock_t lock_instance = {0};
int number;

void *worker(void *arg) {
    for (int i = 0; i < number; i++) {
        lock(&lock_instance, *(int*)arg, *(int*)(arg + sizeof(int)));  // Passer min_backoff et max_backoff
        // Zone critique
        for (int j = 0; j < 10000; j++);
        unlock(&lock_instance);
    }
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 4) {
        return 1;
    }

    int num_threads = atoi(argv[1]);
    int min_backoff = atoi(argv[2]);
    int max_backoff = atoi(argv[3]);
    number =32768 / num_threads;  // Ajuster le nombre d'itérations par thread
    pthread_t threads[num_threads];

    int backoff_args[2] = {min_backoff, max_backoff};
    // Créer les threads
    for (int i = 0; i < num_threads; i++) {
        pthread_create(&threads[i], NULL, worker, (void*)backoff_args);
    }

    // Attendre que tous les threads finissent
    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }

    

    return 0;
}
